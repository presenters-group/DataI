from django.apps import AppConfig


class DataiConfig(AppConfig):
    name = 'DataI'
