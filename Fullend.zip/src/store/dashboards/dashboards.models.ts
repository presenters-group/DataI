
export interface IDashboard {
  visualizers: any[];
  name: string;
}
