export interface MapInterface<T> {
  [id: string]: T
}
